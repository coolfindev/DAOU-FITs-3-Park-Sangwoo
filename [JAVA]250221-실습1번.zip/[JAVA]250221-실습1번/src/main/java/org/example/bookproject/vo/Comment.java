package org.example.bookproject.vo;

import java.util.Date;

public class Comment {
    private int cid;      // 댓글 ID
    private int bid;      // 게시글 ID
    private String mid;      // 작성자 ID (회원 ID)
    private String content; // 댓글 내용
    private Date cdate;   // 작성 날짜

    public int getCid() { return cid; }
    public void setCid(int cid) { this.cid = cid; }

    public int getBid() { return bid; }
    public void setBid(int bid) { this.bid = bid; }

    public String getMid() { return mid; }
    public void setMid(String mid) { this.mid = mid; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public Date getCdate() { return cdate; }
    public void setCdate(Date cdate) { this.cdate = cdate; }
}
