package org.example.bookproject.controller;

import org.apache.ibatis.session.SqlSessionFactory;
import org.example.bookproject.dao.BoardDAO;
import org.example.bookproject.mybatis.MyBatisSessionFactory;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;

@WebServlet(value = "/postDetail")
public class PostDetailServlet extends HttpServlet {

    public PostDetailServlet() {
        System.out.println("PostDetailServlet");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        // 게시글 ID 받아오기
        String bid = req.getParameter("bid");

        if (bid != null) {
            // MyBatis 세션 팩토리
            SqlSessionFactory factory = MyBatisSessionFactory.getSqlSessionFactory();
            BoardDAO boardDAO = new BoardDAO(factory);

            // 게시글 조회
            boardDAO.incrementViewCount(bid);
            HashMap<String, Object> postDetail = boardDAO.selectPostById(bid);

            resp.setContentType("text/html;charset=utf-8");
            System.out.println("--mybatis 연결 완료--");

            if (postDetail != null) {
                // 게시글 정보 request 속성에 설정
                req.setAttribute("postDetail", postDetail);

                // 게시글 상세 페이지로 포워딩
                req.getRequestDispatcher("postDetail.jsp").forward(req, resp);
            } else {
                System.out.println("상세 조회 실패");
            }
        }
    }
}
