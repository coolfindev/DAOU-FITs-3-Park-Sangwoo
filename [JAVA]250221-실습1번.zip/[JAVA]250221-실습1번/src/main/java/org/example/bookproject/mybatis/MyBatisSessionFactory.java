package org.example.bookproject.mybatis;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.Reader;

// 자바 클래스가 하는 일은 DAO가 필요해서
// 이 객체를 통해 SqlSession 객체를 뽑아내는 것이며, 이 객체를 이용해야 SQL을 실행할 수 있게 됨
public class MyBatisSessionFactory {
    private static SqlSessionFactory sqlSessionFactory;

    static {
        try {
            String resource = "SqlMapConfig.xml";  // ✅ 클래스패스 기준 경로
            Reader reader = Resources.getResourceAsReader(resource);


            if (sqlSessionFactory == null) {
                sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static SqlSessionFactory getSqlSessionFactory() {
        return sqlSessionFactory;
    }
}
