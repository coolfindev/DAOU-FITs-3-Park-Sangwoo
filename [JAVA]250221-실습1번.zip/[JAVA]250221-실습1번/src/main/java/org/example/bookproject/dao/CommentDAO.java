package org.example.bookproject.dao;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.example.bookproject.vo.Comment;

import java.util.HashMap;
import java.util.List;

public class CommentDAO {
    private final SqlSessionFactory sqlSessionFactory;

    public CommentDAO(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    // 댓글 목록 조회
    public List<HashMap<String, Object>> getComments(int bid) {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            return session.selectList("test.CommentMapper.getComments", bid);
        }
    }

    // 댓글 추가
    public boolean addComment(Comment comment) {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            int result = session.insert("test.CommentMapper.addComment", comment);
            System.out.println("commentres: " + result);
            session.commit();
            return result > 0;
        }
    }

    // 댓글 삭제
    public boolean deleteComment(int cid) {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            int result = session.delete("test.CommentMapper.deleteComment", cid);
            session.commit();
            return result > 0;
        }
    }
}
