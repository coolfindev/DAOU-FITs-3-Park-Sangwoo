package org.example.bookproject.controller;

import org.apache.ibatis.session.SqlSessionFactory;
import org.example.bookproject.dao.BoardDAO;
import org.example.bookproject.mybatis.MyBatisSessionFactory;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

@WebServlet("/editPost")
public class PostEditServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");

        // 게시글 정보 가져오기
        String bid = req.getParameter("bid");
        String newTitle = req.getParameter("newTitle");
        String newContent = req.getParameter("newContent");

        if (bid != null && newTitle != null && newContent != null) {
            // MyBatis 세션 팩토리
            SqlSessionFactory factory = MyBatisSessionFactory.getSqlSessionFactory();
            BoardDAO boardDAO = new BoardDAO(factory);

            // 게시글 정보 조회
            HashMap<String, Object> postDetail = boardDAO.selectPostById(bid);
            String postWriter = (String) postDetail.get("BWRITER");

            // 세션에서 사용자 정보 가져오기
            HttpSession session = req.getSession();
            String sessionUser = (String) session.getAttribute("username");

                // 게시글 수정
                boolean isPostUpdated = boardDAO.updatePost(bid, newTitle, newContent);

                if (isPostUpdated) {
                    // 수정 성공 시 게시글 목록 페이지로 리다이렉트
                    System.out.println("수정 성공");
                    List<HashMap<String, Object>> postList = boardDAO.selectAllPost();
                    session.setAttribute("posts", postList);  // 게시글 목록을 세션에 저장
                    resp.sendRedirect("main.jsp");
                } else {
                    // 수정 실패 시 에러 처리
                    System.out.println("수정 실패");
                    resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "게시글 수정에 실패했습니다.");
                }
            }
        else {
            // 파라미터가 유효하지 않음
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "잘못된 요청입니다.");
        }
    }
}
