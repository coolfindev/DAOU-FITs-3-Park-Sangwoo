package org.example.bookproject.controller;

import org.apache.ibatis.session.SqlSessionFactory;
import org.example.bookproject.dao.BoardDAO;
import org.example.bookproject.mybatis.MyBatisSessionFactory;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

@WebServlet(value = "/deletePost")
public class PostDeleteServlet extends HttpServlet {

    public PostDeleteServlet() {
        System.out.println("DeletePostServlet");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");

        // 세션에서 사용자 정보 가져오기
        String bid = req.getParameter("bid");

        if (bid != null) {
            // MyBatis 세션 팩토리
            SqlSessionFactory factory = MyBatisSessionFactory.getSqlSessionFactory();
            BoardDAO boardDAO = new BoardDAO(factory);

            // 게시글 정보 조회
            HashMap<String, Object> postDetail = boardDAO.selectPostById(bid);
            String postWriter = (String) postDetail.get("BWRITER");

            // 작성자 확인
                // 게시글 삭제
                boolean isPostDeleted = boardDAO.deletePost(bid);

                if (isPostDeleted) {
                    // 삭제 성공 시 게시글 목록 페이지로 리다이렉트
                    System.out.println("삭제 성공");
                    List<HashMap<String, Object>> postList = boardDAO.selectAllPost();
                    HttpSession session = req.getSession();
                    session.setAttribute("posts", postList);  // 게시글 목록을 세션에 저장

                    resp.sendRedirect("main.jsp");
                } else {
                    // 삭제 실패 시 에러 처리
                    System.out.println("다 됐는데 삭제 실패");
                }
            } else {
                // 작성자와 세션 사용자 불일치
                System.out.println("세션, 작성자 간 불일치");
            }
        }
    }
