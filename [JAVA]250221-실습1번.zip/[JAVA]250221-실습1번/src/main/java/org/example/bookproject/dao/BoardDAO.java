package org.example.bookproject.dao;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.HashMap;
import java.util.List;

public class BoardDAO {
    private SqlSessionFactory sqlSessionFactory;

    public BoardDAO() {}
    public BoardDAO(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public List<HashMap<String, Object>> selectAllPost() {
        List<HashMap<String, Object>> list = null;
        SqlSession sqlSession = sqlSessionFactory.openSession();
        try {
            list = sqlSession.selectList("test.TestBoard.selectAllPost");
            System.out.println("query result:" + list);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            sqlSession.close();
        }
        return list;
    }

    public boolean createPost(String title, String content, String author) {
        boolean isSuccess = false; // 삽입 성공 여부

        SqlSession sqlSession = sqlSessionFactory.openSession();
        try {
            // 파라미터 값을 Map에 넣기
            HashMap<String, Object> map = new HashMap<>();
            map.put("BWRITER", author);
            map.put("BTITLE", title);
            map.put("BCONTENT", content);

            // MyBatis 쿼리 실행
            int result = sqlSession.insert("test.TestBoard.createPost", map);

            // 데이터가 성공적으로 삽입되었는지 확인
            if (result > 0) {
                isSuccess = true; // 성공적으로 데이터가 삽입되었음
            }
            sqlSession.commit(); // 트랜잭션 커밋
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            sqlSession.close();
        }

        return isSuccess;
    }

    public HashMap<String, Object> selectPostById(String bid) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        try {
            return sqlSession.selectOne("test.TestBoard.selectPostById", bid);
        } finally {
            sqlSession.close();
        }
    }

    // 게시글 삭제 메서드
    public boolean deletePost(String bid) {
        try (SqlSession session = sqlSessionFactory.openSession(true)) {
            int result = session.delete("test.TestBoard.deletePost", bid);
            return result > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updatePost(String bid, String newTitle, String newContent) {
        SqlSession session = sqlSessionFactory.openSession();
        try {
            // 게시글을 수정하는 SQL 실행
            HashMap<String, Object> param = new HashMap<>();
            param.put("bid", bid);
            param.put("newTitle", newTitle);
            param.put("newContent", newContent);

            int result = session.update("test.TestBoard.updatePost", param);
            session.commit();
            return result > 0; // 수정이 성공적이면 true
        } catch (Exception e) {
            e.printStackTrace();
            session.rollback();
            return false;
        } finally {
            session.close();
        }
    }
    // 사용자가 특정 게시글에 좋아요를 눌렀는지 확인
    public boolean isPostLikedByUser(String bid, String userId) {
        // HashMap을 사용하여 파라미터를 전달
        HashMap<String, Object> params = new HashMap<>();
        params.put("bid", bid);
        params.put("userId", userId);

        try (SqlSession session = sqlSessionFactory.openSession()) {
            Integer count = session.selectOne("BoardMapper.checkUserLike", params);
            return count != null && count > 0;
        }
    }

    // 좋아요 추가
    public void addLike(String bid, String userId) {
        // HashMap을 사용하여 파라미터를 전달
        System.out.println(bid + " " + userId + " like");
        HashMap<String, Object> params = new HashMap<>();
        params.put("bid", bid);
        params.put("userId", userId);

        try (SqlSession session = sqlSessionFactory.openSession(true)) {
            session.insert("BoardMapper.addLike", params);
        }
    }

    // 좋아요 제거
    public void removeLike(String bid, String userId) {
        // HashMap을 사용하여 파라미터를 전달
        HashMap<String, Object> params = new HashMap<>();
        params.put("bid", bid);
        params.put("userId", userId);

        try (SqlSession session = sqlSessionFactory.openSession(true)) {
            session.delete("BoardMapper.removeLike", params);
        }
    }

    public void incrementViewCount(String bid) {
        try (SqlSession session = sqlSessionFactory.openSession(true)) {
            session.update("test.TestBoard.incrementViewCount", bid);
        }
    }

    public void incrementCommentCount(String bid) {
        try (SqlSession session = sqlSessionFactory.openSession(true)) {
            session.update("test.TestBoard.incrementCommentCount", bid);
        }
    }

    public void decrementCommentCount(String bid) {
        try (SqlSession session = sqlSessionFactory.openSession(true)) {
            session.update("test.TestBoard.decrementCommentCount", bid);
        }
    }
    public void incrementLikeCount(String bid) {
        try (SqlSession session = sqlSessionFactory.openSession(true)) {
            session.update("test.TestBoard.incrementLikeCount", bid);
        }
    }
    public void decrementLikeCount(String bid) {
        try (SqlSession session = sqlSessionFactory.openSession(true)) {
            session.update("test.TestBoard.decrementLikeCount", bid);
        }
    }
}
