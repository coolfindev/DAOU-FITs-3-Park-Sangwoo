package org.example.bookproject.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.ibatis.session.SqlSessionFactory;
import org.example.bookproject.dao.BoardDAO;
import org.example.bookproject.dao.CommentDAO;
import org.example.bookproject.mybatis.MyBatisSessionFactory;
import org.example.bookproject.vo.Comment;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;

@WebServlet(value = "/comment")
public class CommentServlet extends HttpServlet {
    private final CommentDAO commentDAO;

    public CommentServlet() {
        SqlSessionFactory factory = MyBatisSessionFactory.getSqlSessionFactory();
        this.commentDAO = new CommentDAO(factory);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int bid = Integer.parseInt(req.getParameter("bid"));

        // 댓글 목록 가져오기
        List<HashMap<String, Object>> comments = commentDAO.getComments(bid);

        // JSON 형식으로 데이터를 응답
        resp.setContentType("application/json; charset=utf-8");
        PrintWriter out = resp.getWriter();

        // JSON 데이터로 변환
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(comments);

        out.write(json);
        out.flush();
    }


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");

        int bid = Integer.parseInt(req.getParameter("bid"));
        String mid = req.getParameter("mid");
        String content = req.getParameter("content");

        Comment comment = new Comment();
        comment.setBid(bid);
        comment.setMid(mid);
        comment.setContent(content);

        boolean success = commentDAO.addComment(comment);
        if(success) {
            SqlSessionFactory factory = MyBatisSessionFactory.getSqlSessionFactory();
            BoardDAO boardDAO = new BoardDAO(factory);
            boardDAO.incrementCommentCount(req.getParameter("bid"));
        }
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();
        out.write("{ \"success\": " + success + " }");
        out.flush();
}

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("delete params : " +req.getParameter("bid"));
        int cid = Integer.parseInt(req.getParameter("cid"));

        System.out.println("delete cid: " + cid);
        boolean success = commentDAO.deleteComment(cid);
        if(success) {
            SqlSessionFactory factory = MyBatisSessionFactory.getSqlSessionFactory();
            BoardDAO boardDAO = new BoardDAO(factory);
            boardDAO.decrementCommentCount(req.getParameter("bid"));
        }
        resp.getWriter().write(success ? "success" : "failure");
    }
}
