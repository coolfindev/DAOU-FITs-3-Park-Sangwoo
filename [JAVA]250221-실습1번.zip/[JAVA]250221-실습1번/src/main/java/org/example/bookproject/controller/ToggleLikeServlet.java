package org.example.bookproject.controller;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.ibatis.session.SqlSessionFactory;
import org.example.bookproject.dao.BoardDAO;
import org.example.bookproject.mybatis.MyBatisSessionFactory;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashMap;

@WebServlet("/toggleLike")
public class ToggleLikeServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        BufferedReader reader = req.getReader();
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }

        // JSON 파싱
        String jsonData = sb.toString();
        JsonObject jsonObject = JsonParser.parseString(jsonData).getAsJsonObject();
        String bid = jsonObject.get("bid").getAsString();

        HttpSession session = req.getSession();
        HashMap<String, Object> user = (HashMap<String, Object>) session.getAttribute("user");

        if (user == null) {
            resp.getWriter().write("{\"liked\": false}");
            return;
        }

        String userId = (String) user.get("ID");
        SqlSessionFactory factory = MyBatisSessionFactory.getSqlSessionFactory();
        BoardDAO boardDAO = new BoardDAO(factory);

        boolean isLiked = boardDAO.isPostLikedByUser(bid, userId);

        System.out.println("isLiked = " + isLiked);
        if (isLiked) {
            boardDAO.decrementLikeCount(bid);
            boardDAO.removeLike(bid, userId);
        } else {
            boardDAO.incrementLikeCount(bid);
            boardDAO.addLike(bid, userId);
        }

        boolean newLikeStatus = !isLiked;
        resp.getWriter().write("{\"liked\": " + newLikeStatus + "}");
    }
}
