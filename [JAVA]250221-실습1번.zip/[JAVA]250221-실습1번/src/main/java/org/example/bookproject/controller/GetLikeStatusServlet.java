package org.example.bookproject.controller;

import org.apache.ibatis.session.SqlSessionFactory;
import org.example.bookproject.dao.BoardDAO;
import org.example.bookproject.mybatis.MyBatisSessionFactory;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;

@WebServlet("/getLikeStatus")
public class GetLikeStatusServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        String bid = req.getParameter("bid");
        System.out.println("getLikeStatus bid = " + bid);

        HttpSession session = req.getSession();
        HashMap<String, Object> user = (HashMap<String, Object>) session.getAttribute("user");

        if (user == null) {
            resp.getWriter().write("{\"liked\": false}");
            return;
        }

        String userId = (String) user.get("ID");
        SqlSessionFactory factory = MyBatisSessionFactory.getSqlSessionFactory();
        BoardDAO boardDAO = new BoardDAO(factory);

        boolean isLiked = boardDAO.isPostLikedByUser(bid, userId);

        resp.getWriter().write("{\"liked\": " + isLiked + "}");
    }
}
