package org.example.bookproject.controller;

import org.apache.ibatis.session.SqlSessionFactory;
import org.example.bookproject.dao.BoardDAO;
import org.example.bookproject.mybatis.MyBatisSessionFactory;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@WebServlet("/main")
public class PostSearchServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");
        String searchText = req.getParameter("searchText");

        // session에서 posts를 가져오기
        SqlSessionFactory factory = MyBatisSessionFactory.getSqlSessionFactory();
        BoardDAO boardDAO = new BoardDAO(factory);
        List<HashMap<String, Object>> posts = boardDAO.selectAllPost();

        // 검색어가 있을 경우 검색어에 맞는 게시글 필터링
        List<HashMap<String, Object>> filteredPosts = new ArrayList<>();
        for (HashMap<String, Object> post : posts) {
            String title = (String) post.get("BTITLE");
            String content = (String) post.get("BCONTENT");

            System.out.println(searchText + " " + title + " " + content);
            // 제목이나 내용에 검색어가 포함되면 해당 게시글을 추가
            if (title != null && title.contains(searchText) || content != null && content.contains(searchText)) {
                filteredPosts.add(post);
            }
        }

        // 검색 결과를 session에 갱신
        req.getSession().setAttribute("posts", filteredPosts);

        // 검색 결과가 포함된 페이지로 리다이렉트 (또는 다시 메인 페이지로 돌아갈 수도 있음)
        resp.sendRedirect("main.jsp");
    }

   }
