package org.example.bookproject.controller;

import org.apache.ibatis.session.SqlSessionFactory;
import org.example.bookproject.dao.BoardDAO;
import org.example.bookproject.dao.MemberDAO;
import org.example.bookproject.mybatis.MyBatisSessionFactory;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;

@WebServlet(value = "/login")
public class LoginServlet extends HttpServlet {

    public LoginServlet() {
        System.out.println("Login Servlet");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");

        String login = req.getParameter("login");
        String password = req.getParameter("password");

        //-----------------mybatis ------------------
        SqlSessionFactory factory = MyBatisSessionFactory.getSqlSessionFactory();
        MemberDAO memberDAO = new MemberDAO(factory);
        BoardDAO boardDAO = new BoardDAO(factory);

        HashMap<String,Object> user = memberDAO.loginUser(login,password);
        List<HashMap<String,Object>> postList = boardDAO.selectAllPost();

        resp.setContentType("text/html;charset=utf-8");
        System.out.println("--mybatis 연결 완료--");

        if(user != null && postList != null){
            System.out.println(postList);
            HttpSession session = req.getSession();
            session.setAttribute("user",user);
            session.setAttribute("username",user.get("NAME"));
            session.setAttribute("posts", postList);

            RequestDispatcher dispatcher = req.getRequestDispatcher("success.jsp");
            dispatcher.forward(req,resp);

        }else {
            RequestDispatcher dispatcher = req.getRequestDispatcher("error.jsp");
            dispatcher.forward(req,resp);
        }
        }
}
