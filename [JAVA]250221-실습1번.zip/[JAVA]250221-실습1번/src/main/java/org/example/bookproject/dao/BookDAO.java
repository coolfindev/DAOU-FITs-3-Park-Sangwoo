package org.example.bookproject.dao;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.HashMap;
import java.util.List;

public class BookDAO {
    private SqlSessionFactory sqlSessionFactory;

    public BookDAO() {}
    public BookDAO(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public List<HashMap<String, Object>> selectByTitleHashMap(String keyword) {
        List<HashMap<String, Object>> list = null;
        SqlSession sqlSession = sqlSessionFactory.openSession();
        try {
            list = sqlSession.selectList("test.TestBook.selectByTitleHashMap", keyword);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            sqlSession.close();
        }
        return list;
    }

    public HashMap<String, Object> selectDetailBook(String bisbn) {
        HashMap<String, Object> map = null;
        SqlSession sqlSession = sqlSessionFactory.openSession();
        try {
            map = sqlSession.selectOne("test.TestBook.selectDetailBook", bisbn);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            sqlSession.close();
        }
        return map;
    }
}
