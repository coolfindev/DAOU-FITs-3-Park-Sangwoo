package org.example.bookproject.dao;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.HashMap;

public class MemberDAO {
    private SqlSessionFactory sqlSessionFactory;

    public MemberDAO() {}
    public MemberDAO(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public HashMap<String, Object>  loginUser(String id, String pw) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        HashMap<String, Object> result = null;

        try {
            HashMap<String, Object> userInput = new HashMap<>();
            userInput.put("id", id);
            userInput.put("pw", pw);

            result = sqlSession.selectOne("test.TestMember.loginUser", userInput);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            sqlSession.close();
        }
        return result;
    }

}
