package org.example.bookproject.controller;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
@WebServlet(value = "/logout")
public class LogoutServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 세션 가져오기
        HttpSession session = req.getSession();
        session.invalidate();

        // 로그인 페이지 또는 메인 페이지로 리디렉트
        resp.sendRedirect("/BookProject/login.html");
    }
}
