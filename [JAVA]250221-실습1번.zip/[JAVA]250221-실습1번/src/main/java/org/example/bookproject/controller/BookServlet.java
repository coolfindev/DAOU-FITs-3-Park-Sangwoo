package org.example.bookproject.controller;

import org.apache.ibatis.session.SqlSessionFactory;
import org.example.bookproject.dao.BookDAO;
import org.example.bookproject.mybatis.MyBatisSessionFactory;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;

@WebServlet(value = "/book")
public class BookServlet extends HttpServlet {
    public BookServlet() {
        System.out.println("Book Servlet");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");

        String radio = req.getParameter("radio_price");
        String keyword = req.getParameter("keyword");

        //-----------------mybatis ------------------
        SqlSessionFactory factory = MyBatisSessionFactory.getSqlSessionFactory();
        BookDAO bookDAO = new BookDAO(factory);

        List<HashMap<String,Object>> list =bookDAO.selectByTitleHashMap(keyword);

        resp.setContentType("text/html;charset=utf-8");
        System.out.println("--mybatis 연결 완료--");
        System.out.println(list);
        //데이터 타입 먼저 지정

        //1. 결과를 돌려주기 위한 데이터 통로 열기
        PrintWriter out = resp.getWriter();

        //2. 통로를 이용해서 데이터를 전달
        out.println("<html>");
        out.println("<head>");
        out.println("<title>검색 결과</title>");
        out.println("</head>");
        out.println("<body>");

        out.println("<h1>검색결과입니다.</h1>");
        out.println("<h3>검색키워드 : " + keyword + "</h3>");
        out.println("<h3>검색가격 : " + radio + "</h3>");

        out.println("<ul");
        for (HashMap<String,Object> map : list) {
            String bookId = (String) map.get("BISBN"); // 각 책의 고유 ID
            out.println("<li><a href='/BookProject/book/detail?id=" + bookId + "'>" + map.get("BTITLE") + "," + map.get("BPRICE") + "</a></li>");
        }
        out.println("</ul>");

        out.println("</body>");
        out.println("</html>");

        //3. 데이터 밀어내며 지우기
        out.flush();
        out.close();

    }
}
