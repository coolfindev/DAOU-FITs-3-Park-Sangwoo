package org.example.bookproject.controller;

import org.apache.ibatis.session.SqlSessionFactory;
import org.example.bookproject.dao.BoardDAO;
import org.example.bookproject.dao.MemberDAO;
import org.example.bookproject.mybatis.MyBatisSessionFactory;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
@WebServlet(value = "/post")
public class PostServlet extends HttpServlet {

    public PostServlet() {
        System.out.println("PostServlet");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");

        String writer = req.getParameter("writer");
        String title = req.getParameter("title");
        String content = req.getParameter("content");

        //-----------------mybatis ------------------
        SqlSessionFactory factory = MyBatisSessionFactory.getSqlSessionFactory();
        BoardDAO boardDAO = new BoardDAO(factory);

        boolean isPostCreated = boardDAO.createPost(title, content, writer);

        if (isPostCreated) {
            // 글 작성 성공 후 게시글 목록을 세션에 저장
            List<HashMap<String, Object>> postList = boardDAO.selectAllPost();
            HttpSession session = req.getSession();
            session.setAttribute("posts", postList);  // 게시글 목록을 세션에 저장

            // success.jsp로 리다이렉트
            resp.sendRedirect("main.jsp");
        } else {
            // 글 작성 실패 처리
            System.out.println("글 작성 실패");
        }
    }

    // 수정 페이지를 GET 요청으로 처리하는 doGet 추가
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String bid = req.getParameter("bid");  // URL에서 bid 파라미터를 받음

        if (bid != null) {
            // MyBatis 세션 팩토리
            SqlSessionFactory factory = MyBatisSessionFactory.getSqlSessionFactory();
            BoardDAO boardDAO = new BoardDAO(factory);

            // 게시글 정보 조회
            HashMap<String, Object> postDetail = boardDAO.selectPostById(bid);

            // 게시글 정보를 request에 담아서 수정 페이지로 전달
            req.setAttribute("post", postDetail);
            req.getRequestDispatcher("/editPost.jsp").forward(req, resp);  // editPost.jsp로 포워딩
        } else {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "잘못된 요청입니다.");
        }
    }
}

