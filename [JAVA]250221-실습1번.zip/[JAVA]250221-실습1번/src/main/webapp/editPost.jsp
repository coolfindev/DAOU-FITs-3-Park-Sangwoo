<%@ page import="java.util.HashMap" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>게시글 수정</title>
    <script src="https://unpkg.com/@tailwindcss/browser@4"></script>
</head>
<body class="flex items-center justify-center w-full h-screen">
<%
    // 게시글 정보 가져오기
    HashMap<String, Object> postDetail = (HashMap<String, Object>) request.getAttribute("post");
%>
<form action="/BookProject/editPost" method="POST" class="px-20 py-10 shadow-2xl flex flex-col items-center justify-center gap-y-10 p-8 rounded-xl">
    <input type="hidden" name="bid" value="<%= postDetail.get("BID") %>">

    <h1 class="text-xl font-bold">게시글 수정</h1>
    <div>
        <label for="newTitle">제목</label>
        <input type="text" class="border p-2 w-full rounded-lg focus:outline-none border-gray-500" name="newTitle"  id="newTitle" value="<%= postDetail.get("BTITLE") %>" required>
    </div>
    <div>
        <label for="newContent">내용</label>
        <textarea name="newContent" class="border border-gray-500 p-2 w-full h-40 rounded-lg focus:outline-none resize-none" id="newContent" required><%= postDetail.get("BCONTENT") %></textarea>
    </div>
    <button type="submit" class="cursor-pointer bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">수정하기</button>
</form>
</body>
</html>
