<%@ page import="java.util.HashMap" %>
<%@ page import="java.util.List" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>로그인 성공</title>
    <script src="https://unpkg.com/@tailwindcss/browser@4"></script>
</head>
<body class="flex items-center justify-center w-full h-screen">
<div class="p-20 flex flex-col items-center justify-center gap-y-10 p-8 rounded-xl shadow-2xl">
    <div class=" flex flex-col justify-center items-center gap-y-1">
        <span class=" text-2xl"><b class="font-bold"><%= session.getAttribute("username") %></b>님 환영합니다.</span>
        <span class="text-xs text-[#6B6E78]">로그인이 완료되었습니다.</span>
    </div>

    <%
        // 세션이 존재하는지 확인
        String sessionId = session.getId();
        boolean isLoggedIn = sessionId != null;
    %>

    <div class="w-full flex flex-col gap-y-2 justify-end items-center">

        <% if (isLoggedIn) { %>
        <a href="/BookProject/main.jsp" class="border bg-blue-300 text-white cursor-pointer hover:bg-blue-200 transition-all duration-200 ease-in-out rounded-xl px-4 py-2">
            게시판 이동
        </a>
        <form  action="/BookProject/logout" method="GET">
            <%-- 세션 로그아웃 --%> <input type="submit" value="로그아웃"/>
        </form>
        <% } %>
    </div>
<%--    <a href="/BookProject/book.html" class="cursor-pointer w-fit text-center px-20 bg-transparent hover:bg-black hover:text-white transition-all duration-200 ease-in-out border border-gray-300 rounded-xl py-4">도서검색</a>--%>
</div>
</body>
</html>
