$(document).ready(function () {
    const bid = $("#bid").val(); // 숨겨진 input에서 게시글 ID 가져오기
    // ✅ 페이지 로드 시 전체 댓글 불러오기
    function loadComments() {
        console.log(bid);
        $.ajax({
            url: "/BookProject/comment",
            method: "GET",
            dataType: "json",
            data: { bid: bid },
            success: function (data) {
                console.log(data);
                updateCommentList(data);

                console.log("update comment list success");
            },
            error: function (xhr, status, error) {
                console.error("댓글 불러오기 실패:", error);
            }
        });
    }

    // ✅ 댓글 목록 업데이트 함수
    function updateCommentList(data) {
        let commentHTML = "";
        if (data.length > 0) {
            data.forEach(comment => {
                console.log(comment)
                commentHTML += `
                    <div class="border-b py-2 flex justify-between">
                        <div>
                            <strong>${comment.MID}</strong> 
                            <span class="text-gray-500 text-sm">(${new Date(comment.CDATE).toLocaleDateString()})</span>
                            <p>${comment.CONTENT}</p>
                        </div>
                        ${comment.MID === $("#mid").val() ? `<button class="delete-btn text-red-500 text-xs" data-cid="${comment.CID}">삭제</button>` : ""}
                    </div>
                `;
            });
        } else {
            commentHTML = `<p class="text-gray-500 text-center">등록된 댓글이 없습니다.</p>`;
        }
        $("#commentList").html(commentHTML);
    }

    // ✅ 댓글 등록
    $("#commentBtn").on('click', function () {
        const content = $("#commentText").val().trim();
        if (content === "") return alert("댓글을 입력하세요.");

        $.ajax({
            url: "/BookProject/comment",
            method: "POST",
            data: {
                bid: bid,
                mid: $("#mid").val(), // 현재 로그인한 사용자 ID
                content: content
            },
            success: function(response) {
                if (response.success) {
                    $("#commentText").val("");
                    loadComments();
                }
            },
            error: function (xhr, status, error) {
                console.error("댓글 등록 실패:", error);
            }
        });
    });

// ✅ 댓글 삭제
    $("#commentList").on("click", ".delete-btn", function () {
        const cid = $(this).data("cid");
        console.log(cid)
        if (!confirm("댓글을 삭제하시겠습니까?")) return;

        $.ajax({
            url: "/BookProject/comment?cid=" + cid,  // 댓글 삭제 요청 URL
            method: "DELETE",
            success: function () {
                loadComments(); // ✅ 삭제 후 댓글 목록 새로 불러오기
            },
            error: function (xhr, status, error) {
                console.error("댓글 삭제 실패:", error);
            }
        });
    });


    // ✅ 초기 댓글 로딩 실행
    loadComments();
});
