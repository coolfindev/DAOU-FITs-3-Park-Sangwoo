<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.HashMap" %>
<%@ page import="java.util.Date" %>
<%@ page import="java.text.SimpleDateFormat" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>게시글 상세</title>
    <script src="https://cdn.tailwindcss.com"></script> <!-- Tailwind CSS 추가 -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function () {
            // 좋아요 상태 가져오기 (페이지 로드 시)
            $.ajax({
                url: `/BookProject/getLikeStatus`,
                method: 'GET',
                dataType: 'json',
                data: {
                    bid: <%= ((HashMap<String,Object>) request.getAttribute("postDetail")).get("BID") %>
                },
                success: function(data) {
                    if (data.liked) {
                        $("#likebutton").text("좋아요 취소");
                        $("#likebutton").removeClass("bg-gray-500");
                        $("#likebutton").addClass("bg-red-500");
                    }
                },
                error: function(xhr, status, error) {
                    console.error("Error: " + error);
                }
            });

            // 좋아요 버튼 클릭 이벤트
            $("#likebutton").on("click", function () {
                const postId = <%= ((HashMap<String,Object>) request.getAttribute("postDetail")).get("BID") %>;  // 게시글 ID 가져오기

                // Ajax 요청으로 좋아요 상태 토글
                $.ajax({
                    url: "/BookProject/toggleLike",  // 요청 URL
                    method: "POST",
                    contentType: "application/json",
                    data: JSON.stringify({ bid: postId }),  // JSON 형태로 데이터를 보내기
                    success: function (data) {
                        if (data.liked) {
                            $("#likebutton").text("좋아요 취소");
                            $("#likebutton").removeClass("bg-gray-500").addClass("bg-red-500");
                        } else {
                            $("#likebutton").text("좋아요");
                            $("#likebutton").removeClass("bg-red-500").addClass("bg-gray-500");
                        }
                    },
                    error: function (xhr, status, error) {
                        console.error("Error:", error);
                    }
                });
            });
        });
    </script>
</head>
<body class="bg-gray-100 flex items-center justify-center w-full py-40">
<%
    // 세션에서 로그인한 사용자 정보 가져오기
    String loggedInUser = (String) ((HashMap<String, Object>)session.getAttribute("user")).get("ID");  // 세션에서 사용자 정보 가져오기
    String postWriter = (String) ((HashMap<String,Object>) request.getAttribute("postDetail")).get("BWRITER");  // 게시글 작성자

%>
<div class="w-[700px] bg-white shadow-xl rounded-lg py-10 px-20">
    <h1 class="text-3xl font-bold text-center text-gray-800 mb-6">
        <%= ((HashMap<String,Object>) request.getAttribute("postDetail")).get("BTITLE") %>
    </h1>

    <p class="text-gray-600 text-lg mb-4 flex gap-x-2 justify-end items-center text-xs">
        <span>
        <%= ((HashMap<String,Object>) request.getAttribute("postDetail")).get("BWRITER") %>
        </span>

        <span>
            <%
                // BDATE가 Date 타입이라면 SimpleDateFormat을 사용하여 날짜만 포맷
                Date bdate = (Date) ((HashMap<String,Object>) request.getAttribute("postDetail")).get("BDATE");
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String formattedDate = (bdate != null) ? sdf.format(bdate) : "";
            %>
            <%= formattedDate %>
        </span>
    </p>

    <%
        // 로그인한 사용자와 게시글 작성자가 같은지 확인
        if (loggedInUser != null && !loggedInUser.equals(postWriter)) {
    %>
    <div class="flex justify-end items-center text-xs py-2">
        <button id="likebutton" class="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600">
            좋아요
        </button>
    </div>
    <%
        }
    %>


    <p class="text-gray-600 text-lg">
        <strong>내용</strong>
        <span class="block mt-2 pb-10">
            <%= ((HashMap<String,Object>) request.getAttribute("postDetail")).get("BCONTENT") %>
        </span>
    </p>

    <div class="mt-6 text-center">

        <%
            // 로그인한 사용자와 게시글 작성자가 같은지 확인
            if (loggedInUser != null && loggedInUser.equals(postWriter)) {
        %>
        <div class="flex justify-end items-center gap-x-4">
            <!-- 수정 버튼 -->
            <%--            <form action="/BookProject/editPost" method="GET" class="inline-block mt-4">--%>
            <a href="/BookProject/post?bid=<%= ((HashMap<String,Object>) request.getAttribute("postDetail")).get("BID") %>" class="bg-blue-500 text-xs text-white py-2 px-4 rounded-lg hover:bg-blue-600">
                수정하기
            </a>


            <%--            </form>--%>
            <form action="/BookProject/deletePost" method="POST" class="inline-block">
                <input type="hidden" name="bid" value="<%= ((HashMap<String,Object>) request.getAttribute("postDetail")).get("BID") %>">
                <button type="submit" class="bg-red-500 text-xs text-white py-2 px-4 rounded-lg hover:bg-red-600">
                    삭제하기
                </button>
            </form>
        </div>

        <%
            }
        %>

        <hr class="my-4"/>

        <!-- 게시글 ID와 사용자 ID를 숨겨진 input으로 저장 -->
        <input type="hidden" id="bid" value="<%= ((HashMap<String,Object>) request.getAttribute("postDetail")).get("BID") %>">
        <input type="hidden" id="mid" value="<%= loggedInUser %>">


        <!-- 댓글 입력 폼 -->
        <div id="commentForm" class="flex flex-col gap-y-2">
    <textarea id="commentText" placeholder="댓글을 입력하세요"
              class="border border-gray-300 p-2 w-full h-40 rounded-lg focus:outline-none resize-none"></textarea>
            <button type="submit" id="commentBtn" class="border border-gray-300 rounded-xl px-4 py-2">등록</button>
        </div>


        <!-- 댓글 목록 -->
        <div id="commentList" class="my-4"></div>

        <script src="js/comment.js"></script>
    </div>

</div>

</body>
</html>
