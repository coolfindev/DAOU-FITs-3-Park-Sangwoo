<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.HashMap" %>
<%@ page import="java.util.List" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ page import="java.util.Date" %><%--
  Created by IntelliJ IDEA.
  User: daou
  Date: 25. 2. 20.
  Time: 오후 12:08
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>메인 페이지</title>

  <script src="https://unpkg.com/@tailwindcss/browser@4"></script>
</head>
<body>
<div class="p-20 flex flex-col items-center justify-center gap-y-10 p-8 rounded-xl">
  <div class=" flex justify-center items-center">
    <h1 class="text-2xl font-bold">게시판</h1>
  </div>

  <%
    // 세션이 존재하는지 확인
    String sessionId = session.getId();
    boolean isLoggedIn = sessionId != null;
  %>

  <div class="w-full flex justify-end items-center">
    <% if (isLoggedIn) { %>
    <a href="/BookProject/post.jsp" class="border bg-blue-300 text-white cursor-pointer hover:bg-blue-200 transition-all duration-200 ease-in-out rounded-xl px-4 py-2">
      글 작성
    </a>
    <% } %>
  </div>
  <!-- 게시글 리스트 -->
  <form action="/BookProject/main" method="get" class="w-full gap-x-2 flex items-center justify-center">
    <input name="searchText" type="text" placeholder="검색어를 입력하세요."  class="w-[50%] focus:outline-none py-2 rounded-xl border border-gray-300 px-4"/>
    <button name="searchBtn" class=" border rounded-xl border-gray-300 px-4 py-2 cursor-pointer text-gray-500">검색</button>
  </form>
  <div class="w-full max-h-[500px] overflow-y-scroll p-4 rounded-xl">
    <ul class="">
      <li class="flex items-center justify-between font-bold">
        <span class="w-[5%] text-center">ID</span>
        <span class="w-[30%] text-center">제목</span>
        <span class="w-[15%] text-center">작성자</span>
        <span class="w-[15%] text-center">작성일</span>
        <span class="w-[10%] text-center">댓글</span>
        <span class="w-[10%] text-center">좋아요</span>
        <span class="w-[10%] text-center">조회수</span>
      </li>
      <%
        List<HashMap<String, Object>> posts = (List<HashMap<String, Object>>) session.getAttribute("posts");
        if (posts != null && !posts.isEmpty()) {
          for (HashMap<String, Object> post : posts) {
      %>
      <li class="flex justify-between py-4 w-full items-center">
        <span class="w-[5%] text-center"><%= post.get("BID") %></span>

        <a href="/BookProject/postDetail?bid=<%= post.get("BID") %>" class="w-[30%] flex justify-between">
          <span class="hover:underline cursor-pointer"><%= post.get("BTITLE") %></span>
        </a>

        <span class="w-[15%] text-center"><%= post.get("BWRITER") %></span>
        <%
          // BDATE가 Date 타입이라면 SimpleDateFormat을 사용하여 날짜만 포맷
          Date bdate = (Date) post.get("BDATE");
          SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
          String formattedDate = (bdate != null) ? sdf.format(bdate) : "";
        %>
        <span class="w-[15%] text-center"><%= formattedDate  %></span> <!-- 작성일 -->
        <span class="w-[10%] text-center"><%= post.get("BCMTCOUNT") %></span> <!-- 댓글 수 -->
        <span class="w-[10%] text-center"><%= post.get("BLIKES") %></span> <!-- 좋아요 수 -->
        <span class="w-[10%] text-center"><%= post.get("BVIEWCOUNT") %></span> <!-- 조회수 -->
      </li>
      <%
          }
        }
        else {
      %>
        <span class="text-red-300 py-20 flex items-center justify-center">검색 결과가 없습니다!</span>
      <%
          }
      %>
    </ul>

  </div>

  <%--    <a href="/BookProject/book.html" class="cursor-pointer w-fit text-center px-20 bg-transparent hover:bg-black hover:text-white transition-all duration-200 ease-in-out border border-gray-300 rounded-xl py-4">도서검색</a>--%>
</div>
</body>
</html>
