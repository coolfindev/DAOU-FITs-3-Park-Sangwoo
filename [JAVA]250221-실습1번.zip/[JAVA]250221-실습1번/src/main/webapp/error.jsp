<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>로그인 실패</title>
    <script src="https://unpkg.com/@tailwindcss/browser@4"></script>
</head>
<body class="flex items-center justify-center w-full h-screen">
<div class="w-[500px] h-[300px] shadow-2xl flex flex-col items-center justify-center gap-y-10 p-8 rounded-xl">
    <div class=" flex flex-col justify-center items-center gap-y-1">
        <span class=" text-2xl font-bold text-red-400">로그인에 실패했어요!</span>
        <span class="text-xs text-[#6B6E78]">🤕 돌아가서 다시 로그인 해주세요</span>
    </div>
    <a href="/BookProject/login.html" class="cursor-pointer w-fit text-center px-20 bg-transparent hover:bg-black hover:text-white transition-all duration-200 ease-in-out border border-gray-300 rounded-xl py-4">돌아가기</a>
</div>
</body>
</html>
