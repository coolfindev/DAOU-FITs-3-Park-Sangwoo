<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.HashMap" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>글 작성</title>
    <script src="https://unpkg.com/@tailwindcss/browser@4"></script>
</head>
<body class="flex items-center justify-center w-full h-screen">

<%
    // 세션에서 유저 정보 가져오기
    HashMap<String, Object> user = (HashMap<String, Object>) session.getAttribute("user");

    if (user == null) {
        // 로그인 안된 상태 -> 로그인 페이지로 리디렉션
        response.sendRedirect("/BookProject/login.html");
        return;
    }

    String username = (String) user.get("NAME"); // 유저 이름 가져오기
    String bid = (String) user.get("ID");
%>

<div class="px-20 py-10 shadow-2xl flex flex-col items-center justify-center gap-y-10 p-8 rounded-xl">
    <div class="w-full">
        <h1 class="text-2xl text-center font-bold">글 작성</h1>
        <p class="mt-1 text-gray-600 w-full text-end text-xs font-light">작성자: <b><%= username %></b></p>
    </div>

    <form action="/BookProject/post" method="POST" class="w-full flex flex-col gap-y-4">

        <input type="hidden" name="writer" value="<%= bid %>"> <!-- 작성자 정보 hidden input -->

        <div>
            <label for="postTitle" class="text-gray-500">제목</label>
            <input id="postTitle" type="text" name="title" placeholder="제목을 입력하세요"
                   class="border p-2 w-full rounded-lg focus:outline-none border-gray-500">
        </div>

        <div>
            <label for="postContent" class="text-gray-500">내용</label>
            <textarea name="content" id="postContent" placeholder="내용을 입력하세요"
                      class="border border-gray-500 p-2 w-full h-40 rounded-lg focus:outline-none resize-none"></textarea>
        </div>
        <button type="submit" class="cursor-pointer bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">
            글 작성 완료
        </button>
    </form>
</div>

</body>
</html>
