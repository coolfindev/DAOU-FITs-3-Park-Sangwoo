package assignment;

import java.util.Scanner;

public class Test05 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int m = 10;
        int M = 0;
        for(int i=0; i<3; i++) {
            int num = sc.nextInt();
            if (M < num) M = num;
            if (m > num) m = num;
        }
        System.out.println("최대값: "+ M);
        System.out.println("최소값: "+ m);
    }
}