package assignment;

import java.util.Scanner;

public class Test01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n1 = sc.nextInt(); //분자
        int n2 = sc.nextInt(); //분모

        if((double)n1%(double)n2 > 1) {
            System.out.println("나머지가 1보다 크다!");
        } else {
            System.out.println("나머지가 1보다 작거나 같다!");
        }
    }
}
